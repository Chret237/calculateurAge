﻿using System.Windows.Input;

namespace CalculateurAge.ViewModels;

public class CalculateurViewModel : BaseViewModel
{
    private string _nom = string.Empty;
    private DateTime _dateNaissance = DateTime.Today;
    private string _message = string.Empty;
    private int _joursAvantAnniversaire;

    public string Nom
    {
        get => _nom;
        set => SetProperty(ref _nom, value);
    }

    public DateTime DateNaissance
    {
        get => _dateNaissance;
        set => SetProperty(ref _dateNaissance, value);
    }

    public string Message
    {
        get => _message;
        set => SetProperty(ref _message, value);
    }

    public int JoursAvantAnniversaire
    {
        get => _joursAvantAnniversaire;
        set => SetProperty(ref _joursAvantAnniversaire, value);
    }

    public ICommand CalculerCommand { get; }
    public ICommand EffacerCommand { get; }

    public CalculateurViewModel()
    {
        CalculerCommand = new RelayCommand(Calculer);
        EffacerCommand = new RelayCommand(Effacer);
    }

    private async void Calculer()
    {
        int age = DateTime.Today.Year - DateNaissance.Year;

        if (DateNaissance.Date > DateTime.Today.AddYears(-age))
        {
            age--;
        }

        Message = age >= 18 ? "Majeur" : "Mineur";

        DateTime prochainAnniversaire = new DateTime(
            DateTime.Today.Year,
            DateNaissance.Month,
            DateNaissance.Day);

        if (prochainAnniversaire.Date < DateTime.Today)
        {
            prochainAnniversaire = prochainAnniversaire.AddYears(1);
        }

        JoursAvantAnniversaire =
            (prochainAnniversaire.Date - DateTime.Today).Days;

        await Shell.Current.GoToAsync(
            $"{nameof(Views.ResultatPage)}?nom={Nom}&age={age}");
    }

    private void Effacer()
    {
        Nom = string.Empty;
        DateNaissance = DateTime.Today;
        Message = string.Empty;
        JoursAvantAnniversaire = 0;
    }
}